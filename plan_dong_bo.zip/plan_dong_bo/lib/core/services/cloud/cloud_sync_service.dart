import 'package:cloud_firestore/cloud_firestore.dart';

import '../../common/result.dart';
import '../../utilities/firestore_batch.dart';
import '../database/database_service.dart';

class CloudSyncService {
  CloudSyncService._();

  /// Replaces the cloud collection for [tableName] with the current contents of the local table.
  static Future<int> uploadTable({
    required String tableName,
    String? identityColumn,
  }) async {
    final db = DatabaseService.instance.database;
    final rows = await db.query(tableName);

    final firestore = FirebaseFirestore.instance;
    final collection = firestore.collection(tableName);

    await deleteAllDocuments(collection);

    for (final chunk in chunked(rows, firestoreBatchLimit)) {
      final batch = firestore.batch();
      for (final row in chunk) {
        final docId = identityColumn != null ? row[identityColumn]?.toString() : null;
        final docRef = docId != null ? collection.doc(docId) : collection.doc();
        batch.set(docRef, Map<String, dynamic>.from(row));
      }
      await batch.commit();
    }

    return rows.length;
  }

  /// Replaces the local table for [tableName] with the current contents of the cloud collection.
  static Future<int> downloadTable({
    required String tableName,
    String? identityColumn,
  }) async {
    final firestore = FirebaseFirestore.instance;
    final collection = firestore.collection(tableName);

    final snapshot = await collection.get();

    if (snapshot.docs.isEmpty) {
      return 0;
    }

    final db = DatabaseService.instance.database;

    await db.transaction((txn) async {
      await txn.delete(tableName);

      for (final doc in snapshot.docs) {
        final rowMap = Map<String, dynamic>.from(doc.data());
        if (rowMap.isEmpty) continue;

        await txn.insert(tableName, rowMap);
      }
    });

    if (identityColumn != null) {
      final maxIdResult = await db.rawQuery('SELECT MAX($identityColumn) AS maxId FROM $tableName');
      final maxId = maxIdResult.first['maxId'];
      if (maxId != null) {
        await db.rawDelete("DELETE FROM sqlite_sequence WHERE name = '$tableName'");
        await db.rawInsert(
          "INSERT INTO sqlite_sequence(name, seq) VALUES('$tableName', ?)",
          [maxId],
        );
      }
    }

    return snapshot.docs.length;
  }

  /// Deletes every document in the cloud collection for [tableName].
  static Future<int> deleteCloudTable({required String tableName}) async {
    final firestore = FirebaseFirestore.instance;
    final collection = firestore.collection(tableName);

    return deleteAllDocuments(collection);
  }

  /// Writes a single [row] to the cloud collection for [tableName], keyed by [identityColumn].
  static Future<Result<void>> upsertRow({
    required String tableName,
    required String identityColumn,
    required Map<String, dynamic> row,
  }) async {
    try {
      final docId = row[identityColumn]?.toString();
      if (docId == null) return Result.success(data: null);

      await FirebaseFirestore.instance.collection(tableName).doc(docId).set(row, SetOptions(merge: true));

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  /// Deletes a single document identified by [id] from the cloud collection for [tableName].
  static Future<Result<void>> deleteRow({
    required String tableName,
    required String id,
  }) async {
    try {
      await FirebaseFirestore.instance.collection(tableName).doc(id).delete();

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  /// Replaces every document where [whereField] == [whereValue] in the cloud collection for
  /// [tableName] with [newRows]. Used for child rows (e.g. OrderItems/PurchaseItems) whose ids
  /// are regenerated locally whenever their parent is updated.
  static Future<Result<void>> replaceRowsWhere({
    required String tableName,
    required String whereField,
    required dynamic whereValue,
    required String identityColumn,
    required List<Map<String, dynamic>> newRows,
  }) async {
    try {
      final firestore = FirebaseFirestore.instance;
      final collection = firestore.collection(tableName);

      final existing = await collection.where(whereField, isEqualTo: whereValue).get();

      final batch = firestore.batch();

      for (final doc in existing.docs) {
        batch.delete(doc.reference);
      }

      for (final row in newRows) {
        final docId = row[identityColumn]?.toString();
        if (docId == null) continue;

        batch.set(collection.doc(docId), row);
      }

      await batch.commit();

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
