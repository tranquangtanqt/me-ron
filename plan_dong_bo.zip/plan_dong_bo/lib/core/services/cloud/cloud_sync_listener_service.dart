import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sqflite/sqflite.dart';

import '../../utilities/console_logger.dart';
import '../database/database_service.dart';
import 'cloud_sync_target.dart';

/// Applies remote Firestore changes to the local SQLite database in real time, so a change made
/// on one device is reflected on other devices without a manual "sync" action. Firestore only
/// bills reads for documents that actually changed after the initial snapshot, so this stays
/// cheap on the free plan even with a listener kept open per table.
///
/// Meant to run only while the app is in the foreground — start/stop from the app's lifecycle
/// observer (see App).
class CloudSyncListenerService {
  CloudSyncListenerService._();

  static final List<StreamSubscription<QuerySnapshot<Map<String, dynamic>>>> _subscriptions = [];

  static bool get isRunning => _subscriptions.isNotEmpty;

  /// Starts listening to every table in [cloudSyncTargets]. No-op if already running.
  static void start() {
    if (isRunning) return;

    for (final target in cloudSyncTargets) {
      final identityColumn = target.identityColumn;
      if (identityColumn == null) continue;

      final subscription = FirebaseFirestore.instance
          .collection(target.tableName)
          .snapshots()
          .listen(
            (snapshot) => _applySnapshot(target.tableName, identityColumn, snapshot),
            onError: (Object e) {
              cl(
                e,
                title: 'CloudSyncListenerService',
                message: 'Listener error for ${target.tableName}',
                type: LogType.error,
              );
            },
          );

      _subscriptions.add(subscription);
    }
  }

  /// Cancels every active listener.
  static Future<void> stop() async {
    for (final subscription in _subscriptions) {
      await subscription.cancel();
    }

    _subscriptions.clear();
  }

  static Future<void> _applySnapshot(
    String tableName,
    String identityColumn,
    QuerySnapshot<Map<String, dynamic>> snapshot,
  ) async {
    final db = DatabaseService.instance.database;

    for (final change in snapshot.docChanges) {
      try {
        if (change.type == DocumentChangeType.removed) {
          final identityValue = identityColumn == 'code'
              ? change.doc.id
              : (int.tryParse(change.doc.id) ?? change.doc.id);

          await db.delete(tableName, where: '$identityColumn = ?', whereArgs: [identityValue]);

          continue;
        }

        final remoteData = change.doc.data();
        if (remoteData == null) continue;

        final row = Map<String, dynamic>.from(remoteData);
        final identityValue = row[identityColumn] ?? change.doc.id;

        final localRows = await db.query(tableName, where: '$identityColumn = ?', whereArgs: [identityValue]);

        if (localRows.isNotEmpty) {
          final localUpdatedAt = DateTime.tryParse(localRows.first['updatedAt']?.toString() ?? '');
          final remoteUpdatedAt = DateTime.tryParse(row['updatedAt']?.toString() ?? '');

          // Last-write-wins: skip if the local row is already at least as new as the remote one.
          if (localUpdatedAt != null && remoteUpdatedAt != null && !remoteUpdatedAt.isAfter(localUpdatedAt)) {
            continue;
          }
        }

        await db.insert(tableName, row, conflictAlgorithm: ConflictAlgorithm.replace);
      } catch (e) {
        cl(
          e,
          title: 'CloudSyncListenerService',
          message: 'Failed to apply change for $tableName/${change.doc.id}',
          type: LogType.error,
        );
      }
    }
  }
}
