import 'package:sqflite/sqflite.dart';

import '../../../core/common/result.dart';
import '../../models/product_model.dart';

abstract class ProductDatasource {
  Future<Result<int>> createProduct(ProductModel product, {DatabaseExecutor? executor});

  Future<Result<void>> updateProduct(ProductModel product, {DatabaseExecutor? executor});

  Future<Result<void>> deleteProduct(int id, {DatabaseExecutor? executor});

  Future<Result<ProductModel?>> getProduct(int id);

  Future<Result<List<ProductModel>>> getAllProducts({
    String orderBy,
    String sortBy,
    int limit,
    int? offset,
    String? contains,
  });

  // Future<Result<List<ProductModel>>> getUserProducts(
  //   String userId, {
  //   String orderBy,
  //   String sortBy,
  //   int limit,
  //   int? offset,
  //   String? contains,
  // });
}
