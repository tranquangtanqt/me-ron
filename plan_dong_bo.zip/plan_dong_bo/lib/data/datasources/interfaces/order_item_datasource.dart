import 'package:sqflite/sqflite.dart';

import '../../../core/common/result.dart';
import '../../models/order_item_model.dart';
import '../../../domain/usecases/params/base_params.dart';

abstract class OrderItemDatasource {
  Future<Result<int>> createOrderItem(OrderItemModel order, {DatabaseExecutor? executor});

  Future<Result<void>> updateOrderItem(OrderItemModel order, {DatabaseExecutor? executor});

  Future<Result<void>> deleteOrderItem(int id, {DatabaseExecutor? executor});

  Future<Result<OrderItemModel?>> getOrderItem(int id);

  Future<Result<List<OrderItemModel>>> getAllOrderItems(BaseParams params);
}
