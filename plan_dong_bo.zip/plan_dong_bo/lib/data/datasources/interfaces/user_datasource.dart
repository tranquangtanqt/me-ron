import 'package:sqflite/sqflite.dart';

import '../../../core/common/result.dart';
import '../../models/user_model.dart';

abstract class UserDatasource {
  Future<Result<List<UserModel>>> getAllUser();

  Future<Result<UserModel?>> getUser(int id);

  Future<Result<int>> createUser(UserModel user, {DatabaseExecutor? executor});

  Future<Result<void>> updateUser(UserModel user, {DatabaseExecutor? executor});

  Future<Result<void>> deleteUser(int id, {DatabaseExecutor? executor});
}
