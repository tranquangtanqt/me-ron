import 'package:sqflite/sqflite.dart';

import '../../../core/common/result.dart';
import '../../../domain/usecases/params/purchase_params.dart';
import '../../models/purchase_item_model.dart';
import '../../models/purchase_model.dart';

abstract class PurchaseDatasource {
  Future<Result<int>> createPurchase(PurchaseModel purchase, {DatabaseExecutor? executor});

  /// [additionalWrite], if given, runs inside the same SQLite transaction as the purchase + items
  /// insert (e.g. to atomically enqueue an outbox row) — a failure there rolls back everything.
  Future<Result<int>> createPurchaseWithItems(
    PurchaseModel purchase,
    List<PurchaseItemModel> items, {
    Future<Result<void>> Function(Transaction txn)? additionalWrite,
  });

  Future<Result<void>> updatePurchase(PurchaseModel purchase, {DatabaseExecutor? executor});

  Future<Result<void>> updatePurchaseWithItems(
    PurchaseModel purchase,
    List<PurchaseItemModel> items, {
    Future<Result<void>> Function(Transaction txn)? additionalWrite,
  });

  Future<Result<void>> deletePurchase(int id, {Future<Result<void>> Function(Transaction txn)? additionalWrite});

  Future<Result<PurchaseModel?>> getPurchase(int id);

  Future<Result<List<PurchaseModel>>> getAllPurchases(PurchaseParams params);
}
