import 'package:sqflite/sqflite.dart';

import '../../../core/common/result.dart';
import '../../../core/services/database/database_config.dart';
import '../../../core/services/database/database_service.dart';
import '../../models/product_model.dart';
import '../interfaces/product_datasource.dart';

class ProductLocalDatasourceImpl extends ProductDatasource {
  final DatabaseService _databaseService;

  ProductLocalDatasourceImpl(this._databaseService);

  @override
  Future<Result<List<ProductModel>>> getAllProducts({
    String orderBy = 'id',
    String sortBy = 'ASC',
    int limit = 10,
    int? offset,
    String? contains,
  }) async {
    try {
      var res = await _databaseService.database.query(
        DatabaseConfig.productTableName,
        // where: 'categoryId = ? AND name LIKE ?',
        where: 'name LIKE ?',
        whereArgs: ["%${contains ?? ''}%"],
        orderBy: '$orderBy $sortBy',
        // limit: limit,
        offset: offset,
      );
      return res.isEmpty
          ? Result.success(data: [])
          : Result.success(
              data: res.map((e) => ProductModel.fromJson(e)).toList(),
            );
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createProduct(ProductModel product, {DatabaseExecutor? executor}) async {
    try {
      product.updatedAt = DateTime.now().toIso8601String();

      final id = await (executor ?? _databaseService.database).insert(
        DatabaseConfig.productTableName,
        product.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      // The id has been generated in models
      return Result.success(data: id);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateProduct(ProductModel product, {DatabaseExecutor? executor}) async {
    try {
      product.updatedAt = DateTime.now().toIso8601String();

      await (executor ?? _databaseService.database).update(
        DatabaseConfig.productTableName,
        product.toJson(),
        where: 'id = ?',
        whereArgs: [product.id],
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deleteProduct(int id, {DatabaseExecutor? executor}) async {
    try {
      await (executor ?? _databaseService.database).delete(
        DatabaseConfig.productTableName,
        where: 'id = ?',
        whereArgs: [id],
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<ProductModel?>> getProduct(int id) async {
    try {
      var res = await _databaseService.database.query(
        DatabaseConfig.productTableName,
        where: 'id = ?',
        whereArgs: [id],
      );

      if (res.isEmpty) return Result.success(data: null);

      return Result.success(data: ProductModel.fromJson(res.first));
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  // @override
  // Future<Result<List<ProductModel>>> getAllUserProducts(String userId) async {
  //   try {
  //     var res = await _databaseService.database.query(
  //       DatabaseConfig.productTableName,
  //       where: 'categoryId = ?',
  //       whereArgs: [userId],
  //     );
  //
  //     return Result.success(
  //       data: res.map((e) => ProductModel.fromJson(e)).toList(),
  //     );
  //   } catch (e) {
  //     return Result.failure(error: e);
  //   }
  // }

  // @override
  // Future<Result<List<ProductModel>>> getUserProducts(
  //   String userId, {
  //   String orderBy = 'createdAt',
  //   String sortBy = 'DESC',
  //   int limit = 10,
  //   int? offset,
  //   String? contains,
  // }) async {
  //   try {
  //     var res = await _databaseService.database.query(
  //       DatabaseConfig.productTableName,
  //       where: 'createdById = ? AND name LIKE ?',
  //       whereArgs: [userId, "%${contains ?? ''}%"],
  //       orderBy: '$orderBy $sortBy',
  //       limit: limit,
  //       offset: offset,
  //     );
  //
  //     return res.isEmpty
  //       ? Result.success(data: [])
  //       : Result.success(
  //       data: res.map((e) => ProductModel.fromJson(e)).toList(),
  //     );
  //   } catch (e) {
  //     return Result.failure(error: e);
  //   }
  // }
}
