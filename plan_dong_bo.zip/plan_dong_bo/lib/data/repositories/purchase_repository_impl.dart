import 'dart:async';
import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../domain/entities/purchase_entity.dart';
import '../../domain/entities/purchase_item_entity.dart';
import '../../domain/repositories/purchase_repository.dart';
import '../../domain/usecases/params/purchase_params.dart';
import '../datasources/local/purchase_local_datasource_impl.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../models/purchase_item_model.dart';
import '../models/purchase_model.dart';
import '../models/queued_action_model.dart';
import 'atomic_write.dart';
import 'cloud_push_ack.dart';

class PurchaseRepositoryImpl extends PurchaseRepository {
  final PurchaseLocalDatasourceImpl purchaseLocalDatasource;
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  PurchaseRepositoryImpl({
    required this.purchaseLocalDatasource,
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<PurchaseModel>>> getAllPurchases(PurchaseParams params) async {
    try {
      final local = await purchaseLocalDatasource.getAllPurchases(params);
      if (local.isFailure) return Result.failure(error: local.error!);

      final list = local.data ?? [];
      return Result.success(data: list.toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<PurchaseModel?>> getPurchase(int purchaseId) async {
    try {
      final local = await purchaseLocalDatasource.getPurchase(purchaseId);
      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createPurchase(PurchaseEntity purchase) async {
    try {
      final data = PurchaseModel.fromEntity(purchase);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<int>((txn) async {
        final local = await purchaseLocalDatasource.createPurchase(data, executor: txn);
        if (local.isFailure) throw local.error!;

        data.id = local.data!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'PurchaseRepositoryImpl',
          method: 'createPurchase',
          param: jsonEncode(data.toJson()),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;

        return local.data!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.purchaseTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: result.data!);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createPurchaseWithItems(PurchaseEntity purchase, List<dynamic> items) async {
    try {
      final data = PurchaseModel.fromEntity(purchase);
      final itemsModels = items.map((dynamic it) => PurchaseItemModel.fromEntity(it as PurchaseItemEntity)).toList();
      late final QueuedActionModel queuedAction;

      final local = await purchaseLocalDatasource.createPurchaseWithItems(
        data,
        itemsModels,
        additionalWrite: (txn) async {
          queuedAction = QueuedActionModel(
            id: DateTime.now().millisecond,
            repository: 'PurchaseRepositoryImpl',
            method: 'createPurchaseWithItems',
            param: jsonEncode({
              'purchase': data.toJson(),
              'items': itemsModels.map((e) => e.toJson()).toList(),
            }),
            isCritical: true,
            createdAt: DateTime.now().toIso8601String(),
          );

          return queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        },
      );
      if (local.isFailure) return Result.failure(error: local.error!);

      final createdPurchaseId = local.data!;
      data.id = createdPurchaseId;

      unawaited(
        acknowledgeQueuedPushAll(
          queuedActionLocalDatasource,
          queuedAction.id,
          [
            CloudSyncService.upsertRow(
              tableName: DatabaseConfig.purchaseTableName,
              identityColumn: 'id',
              row: data.toJson(),
            ),
            CloudSyncService.replaceRowsWhere(
              tableName: DatabaseConfig.purchaseItemTableName,
              whereField: 'purchaseId',
              whereValue: createdPurchaseId,
              identityColumn: 'id',
              newRows: itemsModels.map((e) => e.toJson()).toList(),
            ),
          ],
        ),
      );

      return Result.success(data: createdPurchaseId);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updatePurchase(PurchaseEntity purchase) async {
    try {
      final purchaseData = PurchaseModel.fromEntity(purchase);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await purchaseLocalDatasource.updatePurchase(purchaseData, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'PurchaseRepositoryImpl',
          method: 'updatePurchase',
          param: jsonEncode(purchaseData.toJson()),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.purchaseTableName,
            identityColumn: 'id',
            row: purchaseData.toJson(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updatePurchaseWithItems(PurchaseEntity purchase, List<dynamic> items) async {
    try {
      final data = PurchaseModel.fromEntity(purchase);
      final itemsModels = items.map((dynamic it) => PurchaseItemModel.fromEntity(it as PurchaseItemEntity)).toList();
      late final QueuedActionModel queuedAction;

      final local = await purchaseLocalDatasource.updatePurchaseWithItems(
        data,
        itemsModels,
        additionalWrite: (txn) async {
          queuedAction = QueuedActionModel(
            id: DateTime.now().millisecond,
            repository: 'PurchaseRepositoryImpl',
            method: 'updatePurchaseWithItems',
            param: jsonEncode({
              'purchase': data.toJson(),
              'items': itemsModels.map((e) => e.toJson()).toList(),
            }),
            isCritical: true,
            createdAt: DateTime.now().toIso8601String(),
          );

          return queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        },
      );
      if (local.isFailure) return Result.failure(error: local.error!);

      unawaited(
        acknowledgeQueuedPushAll(
          queuedActionLocalDatasource,
          queuedAction.id,
          [
            CloudSyncService.upsertRow(
              tableName: DatabaseConfig.purchaseTableName,
              identityColumn: 'id',
              row: data.toJson(),
            ),
            CloudSyncService.replaceRowsWhere(
              tableName: DatabaseConfig.purchaseItemTableName,
              whereField: 'purchaseId',
              whereValue: data.id,
              identityColumn: 'id',
              newRows: itemsModels.map((e) => e.toJson()).toList(),
            ),
          ],
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deletePurchase(int purchaseId) async {
    try {
      late final QueuedActionModel queuedAction;

      final local = await purchaseLocalDatasource.deletePurchase(
        purchaseId,
        additionalWrite: (txn) async {
          queuedAction = QueuedActionModel(
            id: DateTime.now().millisecond,
            repository: 'PurchaseRepositoryImpl',
            method: 'deletePurchase',
            param: purchaseId.toString(),
            isCritical: true,
            createdAt: DateTime.now().toIso8601String(),
          );

          return queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        },
      );
      if (local.isFailure) return Result.failure(error: local.error!);

      unawaited(
        acknowledgeQueuedPushAll(
          queuedActionLocalDatasource,
          queuedAction.id,
          [
            CloudSyncService.deleteRow(
              tableName: DatabaseConfig.purchaseTableName,
              id: purchaseId.toString(),
            ),
            CloudSyncService.replaceRowsWhere(
              tableName: DatabaseConfig.purchaseItemTableName,
              whereField: 'purchaseId',
              whereValue: purchaseId,
              identityColumn: 'id',
              newRows: const [],
            ),
          ],
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
