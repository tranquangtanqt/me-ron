import 'dart:async';
import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../domain/entities/user_entity.dart';
import '../../domain/repositories/user_repository.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../datasources/local/user_local_datasource_impl.dart';
import '../models/queued_action_model.dart';
import '../models/user_model.dart';
import 'atomic_write.dart';
import 'cloud_push_ack.dart';

class UserRepositoryImpl extends UserRepository {
  final UserLocalDatasourceImpl userLocalDatasource;
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  UserRepositoryImpl({
    required this.userLocalDatasource,
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<UserEntity>>> getAllUser() async {
    try {
      var local = await userLocalDatasource.getAllUser();
      if (local.isFailure) return Result.failure(error: local.error!);

      final data = local.data ?? [];

      return Result.success(
        data: data.map((e) => e.toEntity()).toList(),
      );
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<UserEntity?>> getUser(int id) async {
    try {
      var local = await userLocalDatasource.getUser(id);
      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data?.toEntity());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createUser(UserEntity user) async {
    try {
      final data = UserModel.fromEntity(user);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<int>((txn) async {
        final local = await userLocalDatasource.createUser(data, executor: txn);
        if (local.isFailure) throw local.error!;

        data.id = local.data!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'UserRepositoryImpl',
          method: 'createUser',
          param: jsonEncode(data.toJson()),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;

        return local.data!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.userTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: result.data!);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateUser(UserEntity user) async {
    try {
      final data = UserModel.fromEntity(user);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await userLocalDatasource.updateUser(data, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'UserRepositoryImpl',
          method: 'updateUser',
          param: jsonEncode(data.toJson()),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.userTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deleteUser(int id) async {
    try {
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await userLocalDatasource.deleteUser(id, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'UserRepositoryImpl',
          method: 'deleteUser',
          param: id.toString(),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.deleteRow(
            tableName: DatabaseConfig.userTableName,
            id: id.toString(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
