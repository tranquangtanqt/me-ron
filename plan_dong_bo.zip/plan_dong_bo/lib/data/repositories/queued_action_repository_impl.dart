import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../core/utilities/console_logger.dart';
import '../../domain/entities/queued_action_entity.dart';
import '../../domain/repositories/queued_action_repository.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../models/address_model.dart';
import '../models/category_model.dart';
import '../models/order_item_model.dart';
import '../models/order_model.dart';
import '../models/product_model.dart';
import '../models/purchase_item_model.dart';
import '../models/purchase_model.dart';
import '../models/queued_action_model.dart';
import '../models/user_model.dart';

class QueuedActionRepositoryImpl extends QueuedActionRepository {
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  QueuedActionRepositoryImpl({
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<QueuedActionEntity>>> getAllQueuedAction() async {
    try {
      final res = await queuedActionLocalDatasource.getAllUserQueuedAction();
      if (res.isFailure) return Result.failure(error: res.error!);

      return Result.success(data: res.data!.map((e) => e.toEntity()).toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<bool>>> executeAllQueuedActions(List<QueuedActionEntity> queues) async {
    try {
      if (queues.isEmpty) return Result.success(data: []);

      List<bool> result = [];

      for (final queue in queues) {
        // Pass if the internet goes off in the process
        final res = await executeQueuedAction(queue);

        result.add(res.isSuccess);
      }

      return Result.success(data: result);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<bool>> executeQueuedAction(QueuedActionEntity queue) async {
    try {
      cl(QueuedActionModel.fromEntity(queue).toJson());

      final res = await _functionSelector(queue);

      if (res.isSuccess) {
        // Delete executed queue from db
        final deleteRes = await queuedActionLocalDatasource.deleteQueuedAction(queue.id!);
        if (deleteRes.isFailure) return Result.failure(error: res.error!);

        return Result.success(data: true);
      } else {
        return Result.failure(error: res.error ?? 'Unknown error');
      }
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  Future<Result<void>> _functionSelector(QueuedActionEntity queue) async {
    try {
      // Transactions are not part of the cloud sync targets (see cloudSyncTargets) — left as a no-op.
      if (queue.repository == 'TransactionRepositoryImpl') {
        return Result.success(data: null);
      }

      if (queue.repository == 'UserRepositoryImpl') {
        if (queue.method == 'createUser' || queue.method == 'updateUser') {
          final row = UserModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.userTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'deleteUser') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.userTableName, id: queue.param);
        }
      }

      if (queue.repository == 'AddressRepositoryImpl') {
        if (queue.method == 'createAddress' || queue.method == 'updateAddress') {
          final row = AddressModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.addressTableName,
            identityColumn: 'code',
            row: row,
          );
        }

        if (queue.method == 'deleteAddress') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.addressTableName, id: queue.param);
        }
      }

      if (queue.repository == 'CategoryRepositoryImpl') {
        if (queue.method == 'createCategory' || queue.method == 'updateCategory') {
          final row = CategoryModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.categoriesTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'deleteCategory') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.categoriesTableName, id: queue.param);
        }
      }

      if (queue.repository == 'ProductRepositoryImpl') {
        if (queue.method == 'createProduct' || queue.method == 'updateProduct') {
          final row = ProductModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.productTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'deleteProduct') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.productTableName, id: queue.param);
        }
      }

      if (queue.repository == 'OrderRepositoryImpl') {
        if (queue.method == 'createOrder' || queue.method == 'updateOrder') {
          final row = OrderModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'createOrderWithItems' || queue.method == 'updateOrderWithItems') {
          final decoded = jsonDecode(queue.param) as Map<String, dynamic>;
          final orderRow = OrderModel.fromJson(Map<String, dynamic>.from(decoded['order'])).toJson();
          final itemRows = (decoded['items'] as List)
              .map((e) => OrderItemModel.fromJson(Map<String, dynamic>.from(e)).toJson())
              .toList();

          final orderRes = await CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderTableName,
            identityColumn: 'id',
            row: orderRow,
          );
          if (orderRes.isFailure) return Result.failure(error: orderRes.error!);

          return CloudSyncService.replaceRowsWhere(
            tableName: DatabaseConfig.orderItemTableName,
            whereField: 'orderId',
            whereValue: orderRow['id'],
            identityColumn: 'id',
            newRows: itemRows,
          );
        }

        if (queue.method == 'updateStatusOrder') {
          final decoded = jsonDecode(queue.param) as Map<String, dynamic>;

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderTableName,
            identityColumn: 'id',
            row: {
              'id': decoded['id'],
              'status': decoded['status'],
              'updatedAt': DateTime.now().toIso8601String(),
            },
          );
        }

        if (queue.method == 'deleteOrder') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.orderTableName, id: queue.param);
        }
      }

      if (queue.repository == 'OrderItemRepositoryImpl') {
        if (queue.method == 'createOrderItem' || queue.method == 'updateOrderItem') {
          final row = OrderItemModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderItemTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'deleteOrderItem') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.orderItemTableName, id: queue.param);
        }
      }

      if (queue.repository == 'PurchaseRepositoryImpl') {
        if (queue.method == 'createPurchase' || queue.method == 'updatePurchase') {
          final row = PurchaseModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.purchaseTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'createPurchaseWithItems' || queue.method == 'updatePurchaseWithItems') {
          final decoded = jsonDecode(queue.param) as Map<String, dynamic>;
          final purchaseRow = PurchaseModel.fromJson(Map<String, dynamic>.from(decoded['purchase'])).toJson();
          final itemRows = (decoded['items'] as List)
              .map((e) => PurchaseItemModel.fromJson(Map<String, dynamic>.from(e)).toJson())
              .toList();

          final purchaseRes = await CloudSyncService.upsertRow(
            tableName: DatabaseConfig.purchaseTableName,
            identityColumn: 'id',
            row: purchaseRow,
          );
          if (purchaseRes.isFailure) return Result.failure(error: purchaseRes.error!);

          return CloudSyncService.replaceRowsWhere(
            tableName: DatabaseConfig.purchaseItemTableName,
            whereField: 'purchaseId',
            whereValue: purchaseRow['id'],
            identityColumn: 'id',
            newRows: itemRows,
          );
        }

        if (queue.method == 'deletePurchase') {
          final purchaseId = queue.param;

          final deleteRes = await CloudSyncService.deleteRow(
            tableName: DatabaseConfig.purchaseTableName,
            id: purchaseId,
          );
          if (deleteRes.isFailure) return Result.failure(error: deleteRes.error!);

          return CloudSyncService.replaceRowsWhere(
            tableName: DatabaseConfig.purchaseItemTableName,
            whereField: 'purchaseId',
            whereValue: int.tryParse(purchaseId) ?? purchaseId,
            identityColumn: 'id',
            newRows: const [],
          );
        }
      }

      if (queue.repository == 'PurchaseItemRepositoryImpl') {
        if (queue.method == 'createPurchaseItem' || queue.method == 'updatePurchaseItem') {
          final row = PurchaseItemModel.fromJson(jsonDecode(queue.param)).toJson();

          return CloudSyncService.upsertRow(
            tableName: DatabaseConfig.purchaseItemTableName,
            identityColumn: 'id',
            row: row,
          );
        }

        if (queue.method == 'deletePurchaseItem') {
          return CloudSyncService.deleteRow(tableName: DatabaseConfig.purchaseItemTableName, id: queue.param);
        }
      }

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
