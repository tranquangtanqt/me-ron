import 'dart:async';
import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../domain/entities/address_entity.dart';
import '../../domain/repositories/address_repository.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../datasources/local/address_local_datasource_impl.dart';
import '../models/queued_action_model.dart';
import '../models/address_model.dart';
import 'atomic_write.dart';
import 'cloud_push_ack.dart';

class AddressRepositoryImpl extends AddressRepository {
  final AddressLocalDatasourceImpl addressLocalDatasource;
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  AddressRepositoryImpl({
    required this.addressLocalDatasource,
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<AddressEntity>>> getAllAddress() async {
    try {
      var local = await addressLocalDatasource.getAllAddress();
      if (local.isFailure) return Result.failure(error: local.error!);

      final data = local.data ?? [];

      return Result.success(
        data: data.map((e) => e.toEntity()).toList(),
      );
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<AddressEntity?>> getAddress(String code) async {
    try {
      var local = await addressLocalDatasource.getAddress(code);
      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data?.toEntity());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<String>> createAddress(AddressEntity address) async {
    try {
      final data = AddressModel.fromEntity(address);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<String>((txn) async {
        final local = await addressLocalDatasource.createAddress(data, executor: txn);
        if (local.isFailure) throw local.error!;

        data.code = local.data!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'AddressRepositoryImpl',
          method: 'createAddress',
          param: jsonEncode(data.toJson()),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;

        return local.data!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.addressTableName,
            identityColumn: 'code',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: result.data!);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateAddress(AddressEntity address) async {
    try {
      final data = AddressModel.fromEntity(address);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await addressLocalDatasource.updateAddress(data, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'AddressRepositoryImpl',
          method: 'updateAddress',
          param: jsonEncode(data.toJson()),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.addressTableName,
            identityColumn: 'code',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deleteAddress(String code) async {
    try {
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await addressLocalDatasource.deleteAddress(code, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'AddressRepositoryImpl',
          method: 'deleteAddress',
          param: code,
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.deleteRow(
            tableName: DatabaseConfig.addressTableName,
            id: code,
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
