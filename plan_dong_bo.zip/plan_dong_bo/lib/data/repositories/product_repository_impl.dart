import 'dart:async';
import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../domain/entities/product_entity.dart';
import '../../domain/repositories/product_repository.dart';
import '../datasources/local/product_local_datasource_impl.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../models/product_model.dart';
import '../models/queued_action_model.dart';
import 'atomic_write.dart';
import 'cloud_push_ack.dart';
import '../../../domain/usecases/params/base_params.dart';

class ProductRepositoryImpl extends ProductRepository {
  final ProductLocalDatasourceImpl productLocalDatasource;
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  ProductRepositoryImpl({
    required this.productLocalDatasource,
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<ProductEntity>>> getAllProducts(BaseParams params) async {
    try {
      final local = await productLocalDatasource.getAllProducts(
        orderBy: params.orderBy,
        sortBy: params.sortBy,
        limit: params.limit,
        offset: params.offset,
        contains: params.contains,
      );

      if (local.isFailure) return Result.failure(error: local.error!);

      final list = local.data ?? [];
      return Result.success(data: list.map((e) => e.toEntity()).toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<ProductEntity?>> getProduct(int productId) async {
    try {
      final local = await productLocalDatasource.getProduct(productId);
      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data?.toEntity());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createProduct(ProductEntity product) async {
    try {
      final data = ProductModel.fromEntity(product);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<int>((txn) async {
        final local = await productLocalDatasource.createProduct(data, executor: txn);
        if (local.isFailure) throw local.error!;

        data.id = local.data!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'ProductRepositoryImpl',
          method: 'createProduct',
          param: jsonEncode(data.toJson()),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;

        return local.data!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.productTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: result.data!);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deleteProduct(int productId) async {
    try {
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await productLocalDatasource.deleteProduct(productId, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'ProductRepositoryImpl',
          method: 'deleteProduct',
          param: productId.toString(),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.deleteRow(
            tableName: DatabaseConfig.productTableName,
            id: productId.toString(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateProduct(ProductEntity product) async {
    try {
      final data = ProductModel.fromEntity(product);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await productLocalDatasource.updateProduct(data, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'ProductRepositoryImpl',
          method: 'updateProduct',
          param: jsonEncode(data.toJson()),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.productTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
