import 'dart:async';
import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/constants/constants.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../domain/entities/order_entity.dart';
import '../../domain/entities/order_item_entity.dart';
import '../../domain/repositories/order_repository.dart';
import '../../domain/usecases/params/base_params.dart';
import '../../domain/usecases/params/order_params.dart';
import '../../domain/usecases/params/report_customer_params.dart';
import '../../domain/usecases/params/report_order_params.dart';
import '../../domain/usecases/params/report_product_params.dart';
import '../datasources/local/order_local_datasource_impl.dart';
import '../datasources/local/order_item_local_datasource_impl.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../models/customer_summary_model.dart';
import '../models/order_customer_summary_model.dart';
import '../models/order_item_model.dart';
import '../models/order_model.dart';
import '../models/order_status_summary_model.dart';
import '../models/product_summary_model.dart';
import '../models/queued_action_model.dart';
import 'atomic_write.dart';
import 'cloud_push_ack.dart';

class OrderRepositoryImpl extends OrderRepository {
  final OrderLocalDatasourceImpl orderLocalDatasource;
  final OrderItemLocalDatasourceImpl orderItemLocalDatasource;
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  OrderRepositoryImpl({
    required this.orderLocalDatasource,
    required this.orderItemLocalDatasource,
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<OrderModel>>> getAllOrders(OrderParams params) async {
    try {
      final local = await orderLocalDatasource.getAllOrders(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      final list = local.data ?? [];
      // return Result.success(data: list.map((e) => e.toEntity()).toList());
      return Result.success(data: list.toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> getOrdersCount(OrderParams params) async {
    try {
      final local = await orderLocalDatasource.getOrdersCount(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? 0);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<OrderModel>>> getAllOrderReportProduct(ReportProductParams params) async {
    try {
      final local = await orderLocalDatasource.getAllOrderReportProduct(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      final list = local.data ?? [];
      // return Result.success(data: list.map((e) => e.toEntity()).toList());
      return Result.success(data: list.toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> getOrdersCountReportProduct(ReportProductParams params) async {
    try {
      final local = await orderLocalDatasource.getOrdersCountReportProduct(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? 0);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<ProductSummaryModel>>> getProductSummaryReportProduct(ReportProductParams params) async {
    try {
      final local = await orderLocalDatasource.getProductSummaryReportProduct(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? []);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<OrderModel>>> getAllOrderReportOrder(ReportOrderParams params) async {
    try {
      final local = await orderLocalDatasource.getAllOrderReportOrder(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      final list = local.data ?? [];
      // return Result.success(data: list.map((e) => e.toEntity()).toList());
      return Result.success(data: list.toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> getOrdersCountReportOrder(ReportOrderParams params) async {
    try {
      final local = await orderLocalDatasource.getOrdersCountReportOrder(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? 0);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<OrderStatusSummaryModel>>> getOrderStatusSummary(ReportOrderParams params) async {
    try {
      final local = await orderLocalDatasource.getOrderStatusSummary(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? []);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<ProductSummaryModel>>> getOrderProductSummary(ReportOrderParams params) async {
    try {
      final local = await orderLocalDatasource.getOrderProductSummary(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? []);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<OrderCustomerSummaryModel>>> getCustomerSummaryReportOrder(ReportOrderParams params) async {
    try {
      final local = await orderLocalDatasource.getCustomerSummaryReportOrder(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? []);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<CustomerSummaryModel>>> getTopCustomers(ReportCustomerParams params) async {
    try {
      final local = await orderLocalDatasource.getTopCustomers(params);

      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data ?? []);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createOrderWithItems(OrderEntity order, List<dynamic> items) async {
    try {
      final data = OrderModel.fromEntity(order);

      final itemsModels = items.map((dynamic it) => OrderItemModel.fromEntity(it as OrderItemEntity)).toList();
      late final QueuedActionModel queuedAction;

      final local = await orderLocalDatasource.createOrderWithItems(
        data,
        itemsModels,
        additionalWrite: (txn) async {
          queuedAction = QueuedActionModel(
            id: DateTime.now().millisecond,
            repository: 'OrderRepositoryImpl',
            method: 'createOrderWithItems',
            param: jsonEncode({
              'order': data.toJson(),
              'items': itemsModels.map((e) => e.toJson()).toList(),
            }),
            isCritical: true,
            createdAt: DateTime.now().toIso8601String(),
          );

          return queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        },
      );
      if (local.isFailure) return Result.failure(error: local.error!);

      final createdOrderId = local.data!;
      data.id = createdOrderId;

      unawaited(
        acknowledgeQueuedPushAll(
          queuedActionLocalDatasource,
          queuedAction.id,
          [
            CloudSyncService.upsertRow(
              tableName: DatabaseConfig.orderTableName,
              identityColumn: 'id',
              row: data.toJson(),
            ),
            CloudSyncService.replaceRowsWhere(
              tableName: DatabaseConfig.orderItemTableName,
              whereField: 'orderId',
              whereValue: createdOrderId,
              identityColumn: 'id',
              newRows: itemsModels.map((e) => e.toJson()).toList(),
            ),
          ],
        ),
      );

      return Result.success(data: createdOrderId);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<List<OrderModel>>> getOrder(int orderId) async {
    try {
      final local = await orderLocalDatasource.getOrder(orderId);
      if (local.isFailure) return Result.failure(error: local.error!);

      final list = local.data ?? [];
      return Result.success(data: list.toList());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createOrder(OrderEntity order) async {
    try {
      final data = OrderModel.fromEntity(order);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<int>((txn) async {
        final local = await orderLocalDatasource.createOrder(data, executor: txn);
        if (local.isFailure) throw local.error!;

        data.id = local.data!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'OrderRepositoryImpl',
          method: 'createOrder',
          param: jsonEncode(data.toJson()),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;

        return local.data!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: result.data!);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deleteOrder(int orderId) async {
    try {
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await orderLocalDatasource.deleteOrder(orderId, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'OrderRepositoryImpl',
          method: 'deleteOrder',
          param: orderId.toString(),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.deleteRow(
            tableName: DatabaseConfig.orderTableName,
            id: orderId.toString(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateOrder(OrderEntity order) async {
    try {
      final data = OrderModel.fromEntity(order);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await orderLocalDatasource.updateOrder(data, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'OrderRepositoryImpl',
          method: 'updateOrder',
          param: jsonEncode(data.toJson()),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateOrderWithItems(OrderEntity order, List<dynamic> items) async {
    try {
      final data = OrderModel.fromEntity(order);
      final itemsModels = items.map((dynamic it) => OrderItemModel.fromEntity(it as OrderItemEntity)).toList();
      late final QueuedActionModel queuedAction;

      final local = await orderLocalDatasource.updateOrderWithItems(
        data,
        itemsModels,
        additionalWrite: (txn) async {
          queuedAction = QueuedActionModel(
            id: DateTime.now().millisecond,
            repository: 'OrderRepositoryImpl',
            method: 'updateOrderWithItems',
            param: jsonEncode({
              'order': data.toJson(),
              'items': itemsModels.map((e) => e.toJson()).toList(),
            }),
            isCritical: true,
            createdAt: DateTime.now().toIso8601String(),
          );

          return queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        },
      );
      if (local.isFailure) return Result.failure(error: local.error!);

      unawaited(
        acknowledgeQueuedPushAll(
          queuedActionLocalDatasource,
          queuedAction.id,
          [
            CloudSyncService.upsertRow(
              tableName: DatabaseConfig.orderTableName,
              identityColumn: 'id',
              row: data.toJson(),
            ),
            CloudSyncService.replaceRowsWhere(
              tableName: DatabaseConfig.orderItemTableName,
              whereField: 'orderId',
              whereValue: data.id,
              identityColumn: 'id',
              newRows: itemsModels.map((e) => e.toJson()).toList(),
            ),
          ],
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateStatusOrder(int orderId, int status) async {
    try {
      final updatedAt = DateTime.now().toIso8601String();
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await orderLocalDatasource.updateStatusOrder(orderId, status, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecond,
          repository: 'OrderRepositoryImpl',
          method: 'updateStatusOrder',
          param: jsonEncode({
            'id': orderId,
            'status': status,
          }),
          isCritical: true,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.orderTableName,
            identityColumn: 'id',
            row: {
              'id': orderId,
              'status': status,
              'updatedAt': updatedAt,
            },
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
