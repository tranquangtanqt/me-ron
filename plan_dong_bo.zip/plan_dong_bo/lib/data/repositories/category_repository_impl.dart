import 'dart:async';
import 'dart:convert';

import '../../core/common/result.dart';
import '../../core/services/cloud/cloud_sync_service.dart';
import '../../core/services/database/database_config.dart';
import '../../domain/entities/category_entity.dart';
import '../../domain/repositories/category_repository.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';
import '../datasources/local/category_local_datasource_impl.dart';
import '../models/queued_action_model.dart';
import '../models/category_model.dart';
import 'atomic_write.dart';
import 'cloud_push_ack.dart';

class CategoryRepositoryImpl extends CategoryRepository {
  final CategoryLocalDatasourceImpl categoryLocalDatasource;
  final QueuedActionLocalDatasourceImpl queuedActionLocalDatasource;

  CategoryRepositoryImpl({
    required this.categoryLocalDatasource,
    required this.queuedActionLocalDatasource,
  });

  @override
  Future<Result<List<CategoryEntity>>> getAllCategory() async {
    try {
      var local = await categoryLocalDatasource.getAllCategory();
      if (local.isFailure) return Result.failure(error: local.error!);

      final data = local.data ?? [];

      return Result.success(
        data: data.map((e) => e.toEntity()).toList(),
      );
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<CategoryEntity?>> getCategory(int id) async {
    try {
      var local = await categoryLocalDatasource.getCategory(id);
      if (local.isFailure) return Result.failure(error: local.error!);

      return Result.success(data: local.data?.toEntity());
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<int>> createCategory(CategoryEntity category) async {
    try {
      final data = CategoryModel.fromEntity(category);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<int>((txn) async {
        final local = await categoryLocalDatasource.createCategory(data, executor: txn);
        if (local.isFailure) throw local.error!;

        data.id = local.data!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'CategoryRepositoryImpl',
          method: 'createCategory',
          param: jsonEncode(data.toJson()),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;

        return local.data!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.categoriesTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: result.data!);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> updateCategory(CategoryEntity category) async {
    try {
      final data = CategoryModel.fromEntity(category);
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await categoryLocalDatasource.updateCategory(data, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'CategoryRepositoryImpl',
          method: 'updateCategory',
          param: jsonEncode(data.toJson()),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.upsertRow(
            tableName: DatabaseConfig.categoriesTableName,
            identityColumn: 'id',
            row: data.toJson(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }

  @override
  Future<Result<void>> deleteCategory(int id) async {
    try {
      late final QueuedActionModel queuedAction;

      final result = await runAtomically<void>((txn) async {
        final local = await categoryLocalDatasource.deleteCategory(id, executor: txn);
        if (local.isFailure) throw local.error!;

        queuedAction = QueuedActionModel(
          id: DateTime.now().millisecondsSinceEpoch,
          repository: 'CategoryRepositoryImpl',
          method: 'deleteCategory',
          param: id.toString(),
          isCritical: false,
          createdAt: DateTime.now().toIso8601String(),
        );

        final queued = await queuedActionLocalDatasource.createQueuedAction(queuedAction, executor: txn);
        if (queued.isFailure) throw queued.error!;
      });

      if (result.isFailure) return Result.failure(error: result.error!);

      unawaited(
        acknowledgeQueuedPush(
          queuedActionLocalDatasource,
          queuedAction.id,
          CloudSyncService.deleteRow(
            tableName: DatabaseConfig.categoriesTableName,
            id: id.toString(),
          ),
        ),
      );

      return Result.success(data: null);
    } catch (e) {
      return Result.failure(error: e);
    }
  }
}
