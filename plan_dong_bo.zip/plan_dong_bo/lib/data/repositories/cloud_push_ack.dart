import '../../core/common/result.dart';
import '../datasources/local/queued_action_local_datasource_impl.dart';

/// Awaits [pushFuture] (a Firestore push kicked off right after a local write) and clears the
/// matching `QueuedActions` row on success, so the retry outbox doesn't replay a change the direct
/// push already delivered. Left in place on failure (e.g. offline) so the existing retry path
/// (`QueuedActionRepositoryImpl.executeAllQueuedActions`) can pick it up later.
Future<void> acknowledgeQueuedPush(
  QueuedActionLocalDatasourceImpl queuedActionLocalDatasource,
  int queuedActionId,
  Future<Result<void>> pushFuture,
) async {
  final res = await pushFuture;

  if (res.isSuccess) {
    await queuedActionLocalDatasource.deleteQueuedAction(queuedActionId);
  }
}

/// Same as [acknowledgeQueuedPush] but for a change that pushes more than one Firestore write
/// (e.g. an order plus its items) under a single queued action — the queue entry is only cleared
/// once every push in [pushFutures] has succeeded.
Future<void> acknowledgeQueuedPushAll(
  QueuedActionLocalDatasourceImpl queuedActionLocalDatasource,
  int queuedActionId,
  List<Future<Result<void>>> pushFutures,
) async {
  final results = await Future.wait(pushFutures);

  if (results.every((res) => res.isSuccess)) {
    await queuedActionLocalDatasource.deleteQueuedAction(queuedActionId);
  }
}
