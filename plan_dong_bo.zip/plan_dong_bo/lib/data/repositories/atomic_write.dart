import 'package:sqflite/sqflite.dart';

import '../../core/common/result.dart';
import '../../core/services/database/database_service.dart';

/// Runs [action] inside a single SQLite transaction and converts a thrown error (typically the
/// `error` of an inner [Result.failure]) back into a [Result.failure] for the caller.
///
/// Used to make a local write and its outbox `QueuedActions` enqueue succeed or fail together —
/// without this, a process kill between the two writes could leave the local row updated with no
/// record that the change still needs to reach the cloud.
Future<Result<T>> runAtomically<T>(Future<T> Function(Transaction txn) action) async {
  try {
    final data = await DatabaseService.instance.database.transaction(action);
    return Result.success(data: data);
  } catch (e) {
    return Result.failure(error: e);
  }
}
