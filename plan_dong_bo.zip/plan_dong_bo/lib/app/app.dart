import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/locale/app_locale.dart';
import '../core/services/cloud/cloud_sync_listener_service.dart';
import '../presentation/providers/theme/theme_notifier.dart';
import 'di/app_providers.dart';
import 'error/error_handler_builder.dart';

class App extends ConsumerStatefulWidget {
  const App({super.key});

  @override
  ConsumerState<App> createState() => _AppState();
}

class _AppState extends ConsumerState<App> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    CloudSyncListenerService.start();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        CloudSyncListenerService.start();
        break;
      case AppLifecycleState.detached:
        // Only tear down on full process teardown — Firestore listeners are push-based and stay
        // cheap while briefly backgrounded, and re-subscribing on every paused/inactive would
        // force the SDK to replay its entire local cache as `added` doc changes each time.
        CloudSyncListenerService.stop();
        break;
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    CloudSyncListenerService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = ref.watch(themeNotifierProvider.select((s) => s.themeData));
    final router = ref.watch(appRoutesProvider).router;

    return MaterialApp.router(
      title: 'Mẹ Rôn',
      theme: theme,
      debugShowCheckedModeBanner: kDebugMode,
      routerConfig: router,
      locale: AppLocale.defaultLocale,
      supportedLocales: AppLocale.supportedLocales,
      localizationsDelegates: AppLocale.localizationsDelegates,
      builder: (context, child) => ErrorHandlerBuilder(child: child),
    );
  }
}
