# Real-time row-level cloud sync (Firestore Spark, 2-3 thiết bị)

## Context

App hiện có tính năng backup/restore Firebase thủ công (`CloudSyncService.uploadTable`/`downloadTable` trong [cloud_sync_service.dart](lib/core/services/cloud/cloud_sync_service.dart)): mỗi lần bấm nút, nó **xóa sạch** collection Firestore rồi ghi lại **toàn bộ** bảng SQLite, và ngược lại. Cách này tốn băng thông không cần thiết cho một thay đổi nhỏ (vd sửa 1 đơn hàng), điều quan trọng khi dùng gói Firebase Free với chỉ 2-3 thiết bị.

Mục tiêu: SQLite vẫn là nguồn đọc chính (không đổi luồng đọc hiện tại). Khi thiết bị A thêm/sửa/xóa 1 dòng, chỉ dòng đó được đẩy lên Firestore; các thiết bị khác (đang mở app) nhận thay đổi qua Firestore realtime listener và áp trực tiếp vào SQLite của họ — không phải tải lại cả bảng. Xung đột hiếm gặp (2-3 thiết bị) được xử lý bằng last-write-wins dựa trên `updatedAt`. Listener chỉ chạy khi app đang foreground để tiết kiệm pin/kết nối.

Điểm quan trọng phát hiện khi khảo sát: mỗi repository (Product, Address, Category, User, Order, OrderItem, Purchase, PurchaseItem) **đã** ghi một `QueuedActionModel` (tên repo, method, JSON của row, `isCritical`, `createdAt`) vào bảng `QueuedActions` sau mỗi lần ghi local — xem [product_repository_impl.dart](lib/data/repositories/product_repository_impl.dart) và [address_repository_impl.dart](lib/data/repositories/address_repository_impl.dart). Đây vốn là một "outbox" được chuẩn bị sẵn cho việc đồng bộ remote nhưng consumer của nó — `QueuedActionRepositoryImpl._functionSelector` trong [queued_action_repository_impl.dart](lib/data/repositories/queued_action_repository_impl.dart) — hiện toàn bộ code gọi remote datasource đã bị **comment out** (chỉ xóa queue và trả `success` giả). Kế hoạch này tận dụng đúng cơ chế có sẵn đó thay vì xây mới.

## Thiết kế

### 1. Đẩy thay đổi lên cloud (push, khi đang online)
- Thêm các hàm tĩnh mới vào `CloudSyncService`:
  - `upsertRow({tableName, identityColumn, row})` → `Result<void>`: ghi 1 document (`collection(tableName).doc(row[identityColumn])`) bằng `.set(row)`.
  - `deleteRow({tableName, id})` → `Result<void>`: xóa 1 document.
  - `replaceRowsWhere({tableName, whereField, whereValue, identityColumn, newRows})` → `Result<void>`: dùng cho OrderItems/PurchaseItems khi cha (Order/Purchase) được update — đọc các doc có `whereField == whereValue`, xóa hết rồi ghi lại `newRows` bằng batch (tái dùng `chunked`/`firestoreBatchLimit` có sẵn trong [firestore_batch.dart](lib/core/utilities/firestore_batch.dart)), vì `updateOrderWithItems`/`updatePurchaseWithItems` xóa hết item cũ và tạo lại item mới với id khác ở local.
  - Mọi lỗi (mất mạng...) được bắt và trả về `Result.failure`, không throw — để nơi gọi tùy chọn `unawaited` (không chặn UI) hoặc `await` (khi cần biết kết quả để xóa queue, xem mục 3).

- Trong **mỗi** repository ghi dữ liệu (8 file `*_repository_impl.dart` tương ứng 8 bảng đang có trong `cloudSyncTargets`), ngay sau khi ghi local thành công và trước/sau khi enqueue `QueuedActionModel` như hiện tại, thêm một dòng `unawaited(CloudSyncService.upsertRow(...))` hoặc `deleteRow(...)` — tái sử dụng đúng `data.toJson()`/`AddressModel.fromEntity(...).toJson()` đã có sẵn ở đó cho `QueuedActionModel.param`. Đây là "phát tín hiệu" real-time khi có mạng.
  - File đại diện cho pattern lặp lại: [product_repository_impl.dart](lib/data/repositories/product_repository_impl.dart) (createProduct/updateProduct/deleteProduct), áp dụng tương tự cho address, category, user, order, order_item, purchase, purchase_item.
  - Trường hợp đặc biệt: `createOrderWithItems`/`updateOrderWithItems` trong [order_local_datasource_impl.dart](lib/data/datasources/local/order_local_datasource_impl.dart) (được gọi từ `order_repository_impl.dart`) và `createPurchaseWithItems`/`updatePurchaseWithItems` tương tự cho Purchase — sau khi transaction local commit, push riêng cho Order/Purchase (`upsertRow`) và dùng `replaceRowsWhere` cho toàn bộ OrderItems/PurchaseItems theo `orderId`/`purchaseId`.

- Fix `identityColumn` bị thiếu cho Address trong [cloud_sync_target.dart](lib/core/services/cloud/cloud_sync_target.dart): đổi thành `identityColumn: 'code'` (PK thật của bảng Address) — cần cho cả push lẫn listener ở bước 2.

### 2. Nhận thay đổi từ cloud (pull, realtime listener)
- Tạo service tĩnh mới `lib/core/services/cloud/cloud_sync_listener_service.dart`, theo đúng phong cách static của `CloudSyncService` (không cần Riverpod provider):
  - `start()`: với mỗi `CloudSyncTarget` trong `cloudSyncTargets`, mở `FirebaseFirestore.instance.collection(tableName).snapshots().listen(...)`, lưu `StreamSubscription` vào danh sách tĩnh. Bỏ qua nếu đã có listener đang chạy (idempotent).
  - Trong callback, duyệt `snapshot.docChanges`:
    - `added`/`modified`: đọc `updatedAt` của doc; so với `updatedAt` của dòng local cùng `identityColumn` (query 1 dòng bằng `db.query(tableName, where: '$identityColumn = ?', whereArgs: [doc.id])`). Nếu local không có dòng, hoặc `updatedAt` remote mới hơn/bằng → `db.insert(tableName, doc.data(), conflictAlgorithm: ConflictAlgorithm.replace)` (upsert).
    - `removed`: `db.delete(tableName, where: '$identityColumn = ?', whereArgs: [doc.id])`.
  - `stop()`: hủy toàn bộ `StreamSubscription`, xóa danh sách.
  - Tự ghi đè lại đúng dữ liệu mình vừa gửi (echo từ chính thiết bị) là vô hại vì thao tác upsert là idempotent — không cần logic "bỏ qua thay đổi của chính mình".

### 3. Retry khi mất mạng lúc ghi
- `QueuedActionModel` hiện tại đã được enqueue ở bước 1 cho mọi thao tác (kể cả khi push trực tiếp thất bại) — đây là fallback có sẵn.
- Điền code thật vào `_functionSelector` trong [queued_action_repository_impl.dart](lib/data/repositories/queued_action_repository_impl.dart): thay các block comment bằng lệnh gọi `CloudSyncService.upsertRow`/`deleteRow` tương ứng (decode `queue.param` bằng model `fromJson`), dùng kết quả `Result` để quyết định `res.isSuccess` (giữ nguyên logic xóa queue khi thành công đã có ở `executeQueuedAction`). Thêm các nhánh còn thiếu cho `AddressRepositoryImpl`, `CategoryRepositoryImpl`, `OrderRepositoryImpl`, `OrderItemRepositoryImpl`, `PurchaseRepositoryImpl`, `PurchaseItemRepositoryImpl` (hiện chỉ có User/Transaction/Product, đều đang là code mẫu commented-out).
- **Không** thay đổi cơ chế trigger hiện có (`checkAndSyncAllData`/`initMainProvider` trong [main_notifier.dart](lib/presentation/providers/main/main_notifier.dart) chỉ chạy lúc mở app) — việc gắn theo dõi kết nối mạng thực (connectivity_plus...) để tự động retry khi có mạng lại là một gap có sẵn từ trước, nằm ngoài phạm vi yêu cầu lần này. Sẽ nêu rõ đây là hạn chế đã biết.

### 4. Vòng đời (dừng khi app bị đóng hẳn, không dừng khi chỉ tạm rời foreground)
- Chuyển [app.dart](lib/app/app.dart) từ `ConsumerWidget` sang `ConsumerStatefulWidget` + `WidgetsBindingObserver`:
  - `initState`: đăng ký observer, gọi `CloudSyncListenerService.start()`.
  - `didChangeAppLifecycleState`: `resumed` → `start()`; `detached` (tiến trình bị hệ điều hành hủy) → `stop()`; `paused`/`inactive`/`hidden` (chuyển app tạm thời, khóa màn hình) → không làm gì.
  - `dispose`: gỡ observer, `stop()`.
- Lý do không `stop()` ở `paused`/`inactive` như thiết kế ban đầu: `.collection(tableName).snapshots()` khi được attach lại sẽ phát lại toàn bộ cache cục bộ dưới dạng `docChanges` kiểu `added` (Firestore không tính phí đọc lại nhờ cơ chế resume-token, nhưng code `_applySnapshot` vẫn phải duyệt + so `updatedAt` cho từng dòng cache mỗi lần) — vì listener Firestore là kết nối push gần như miễn phí khi app ở background ngắn hạn, chỉ cần dừng khi tiến trình thực sự bị hủy để tránh việc resubscribe lặp lại không cần thiết.

### 5. Giữ nguyên tính năng backup thủ công
- 3 màn hình upload/download/delete cloud hiện tại giữ nguyên, dùng như công cụ "đồng bộ lại toàn bộ" thủ công (setup máy mới, khôi phục sau sự cố) — chỉ hưởng lợi gián tiếp từ việc `cloud_sync_target.dart` được sửa `identityColumn` cho Address.

## Không cần migration schema
Tất cả 8 bảng đã có sẵn cột `updatedAt` (xem [database_config.dart](lib/core/services/database/database_config.dart)) nên không cần tăng `DatabaseConfig.version`. Cần đảm bảo `updatedAt` được set lại đúng thời điểm ghi: trong mỗi `*_local_datasource_impl.dart`, ở hàm `create*`/`update*`, ghi đè `updatedAt: DateTime.now().toIso8601String()` vào map trước khi `insert`/`update` (hiện tại giá trị này phụ thuộc dữ liệu model truyền vào, không đảm bảo luôn là thời điểm ghi thật) — đây là điều kiện bắt buộc để last-write-wins hoạt động đúng.

## Verification
- `flutter analyze` sau khi sửa.
- Chạy thử với 2 máy ảo/thiết bị thật cùng trỏ vào project Firebase hiện tại (`me-ron`, xem [firebase_options.dart](lib/firebase_options.dart)):
  1. Mở app ở cả 2 máy (foreground).
  2. Thêm/sửa 1 sản phẩm ở máy A → xác nhận máy B tự cập nhật danh sách sản phẩm mà không cần bấm nút đồng bộ thủ công, và không xóa/ghi lại toàn bộ collection Firestore (kiểm tra trong Firebase Console > Firestore rằng chỉ 1 document Products bị thay đổi thời điểm đó).
  3. Sửa 1 đơn hàng có items ở máy A → xác nhận máy B nhận đúng order + đúng bộ item mới (không còn item cũ).
  4. Tắt mạng ở máy A, sửa 1 dòng, bật mạng lại, mở lại app (trigger `initMainProvider`) → xác nhận dòng đó được đẩy lên qua đường retry (`executeAllQueuedActions`).
  5. Đưa app xuống background ngắn (không đóng hẳn) ở máy B, sửa dữ liệu ở máy A, mở lại app B → xác nhận B vẫn nhận được thay đổi gần như ngay lập tức (listener không bị dừng ở paused/inactive nên vẫn giữ kết nối).
  6. Đóng hẳn app B (kill task) rồi mở lại → xác nhận vẫn nhận được thay đổi đã bỏ lỡ trong lúc đóng (qua resume token của Firestore khi listener khởi động lại), và không thấy có yêu cầu đọc lại toàn bộ collection trên Firebase Console > Firestore > Usage sau lần đầu.
